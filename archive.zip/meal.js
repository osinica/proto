"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MealServiceClientImpl = exports.FindOneResponse = exports.FindOneRequest = exports.CreateMealResponse = exports.CreateMealRequest = exports.Meal = exports.statusToJSON = exports.statusFromJSON = exports.Status = exports.timeToJSON = exports.timeFromJSON = exports.Time = exports.protobufPackage = void 0;
var _m0 = require("protobufjs/minimal");
exports.protobufPackage = "meal";
var Time;
(function (Time) {
    Time[Time["SHORT"] = 0] = "SHORT";
    Time[Time["MEDIUM"] = 1] = "MEDIUM";
    Time[Time["LONG"] = 2] = "LONG";
    Time[Time["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Time = exports.Time || (exports.Time = {}));
function timeFromJSON(object) {
    switch (object) {
        case 0:
        case "SHORT":
            return Time.SHORT;
        case 1:
        case "MEDIUM":
            return Time.MEDIUM;
        case 2:
        case "LONG":
            return Time.LONG;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Time.UNRECOGNIZED;
    }
}
exports.timeFromJSON = timeFromJSON;
function timeToJSON(object) {
    switch (object) {
        case Time.SHORT:
            return "SHORT";
        case Time.MEDIUM:
            return "MEDIUM";
        case Time.LONG:
            return "LONG";
        case Time.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
exports.timeToJSON = timeToJSON;
var Status;
(function (Status) {
    Status[Status["SUCCESS"] = 0] = "SUCCESS";
    Status[Status["ERROR"] = 1] = "ERROR";
    Status[Status["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Status = exports.Status || (exports.Status = {}));
function statusFromJSON(object) {
    switch (object) {
        case 0:
        case "SUCCESS":
            return Status.SUCCESS;
        case 1:
        case "ERROR":
            return Status.ERROR;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Status.UNRECOGNIZED;
    }
}
exports.statusFromJSON = statusFromJSON;
function statusToJSON(object) {
    switch (object) {
        case Status.SUCCESS:
            return "SUCCESS";
        case Status.ERROR:
            return "ERROR";
        case Status.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
exports.statusToJSON = statusToJSON;
function createBaseMeal() {
    return { id: "", name: "", duration: 0 };
}
exports.Meal = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.name !== "") {
            writer.uint32(18).string(message.name);
        }
        if (message.duration !== 0) {
            writer.uint32(24).int32(message.duration);
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseMeal();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
                case 2:
                    if (tag !== 18) {
                        break;
                    }
                    message.name = reader.string();
                    continue;
                case 3:
                    if (tag !== 24) {
                        break;
                    }
                    message.duration = reader.int32();
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return {
            id: isSet(object.id) ? String(object.id) : "",
            name: isSet(object.name) ? String(object.name) : "",
            duration: isSet(object.duration) ? timeFromJSON(object.duration) : 0,
        };
    },
    toJSON: function (message) {
        var obj = {};
        message.id !== undefined && (obj.id = message.id);
        message.name !== undefined && (obj.name = message.name);
        message.duration !== undefined && (obj.duration = timeToJSON(message.duration));
        return obj;
    },
    create: function (base) {
        return exports.Meal.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a, _b, _c;
        var message = createBaseMeal();
        message.id = (_a = object.id) !== null && _a !== void 0 ? _a : "";
        message.name = (_b = object.name) !== null && _b !== void 0 ? _b : "";
        message.duration = (_c = object.duration) !== null && _c !== void 0 ? _c : 0;
        return message;
    },
};
function createBaseCreateMealRequest() {
    return { name: "", duration: 0 };
}
exports.CreateMealRequest = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.duration !== 0) {
            writer.uint32(16).int32(message.duration);
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseCreateMealRequest();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 10) {
                        break;
                    }
                    message.name = reader.string();
                    continue;
                case 2:
                    if (tag !== 16) {
                        break;
                    }
                    message.duration = reader.int32();
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return {
            name: isSet(object.name) ? String(object.name) : "",
            duration: isSet(object.duration) ? timeFromJSON(object.duration) : 0,
        };
    },
    toJSON: function (message) {
        var obj = {};
        message.name !== undefined && (obj.name = message.name);
        message.duration !== undefined && (obj.duration = timeToJSON(message.duration));
        return obj;
    },
    create: function (base) {
        return exports.CreateMealRequest.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a, _b;
        var message = createBaseCreateMealRequest();
        message.name = (_a = object.name) !== null && _a !== void 0 ? _a : "";
        message.duration = (_b = object.duration) !== null && _b !== void 0 ? _b : 0;
        return message;
    },
};
function createBaseCreateMealResponse() {
    return { status: 0, error: "", data: undefined };
}
exports.CreateMealResponse = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.status !== 0) {
            writer.uint32(8).int32(message.status);
        }
        if (message.error !== "") {
            writer.uint32(18).string(message.error);
        }
        if (message.data !== undefined) {
            exports.Meal.encode(message.data, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseCreateMealResponse();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 8) {
                        break;
                    }
                    message.status = reader.int32();
                    continue;
                case 2:
                    if (tag !== 18) {
                        break;
                    }
                    message.error = reader.string();
                    continue;
                case 3:
                    if (tag !== 26) {
                        break;
                    }
                    message.data = exports.Meal.decode(reader, reader.uint32());
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return {
            status: isSet(object.status) ? statusFromJSON(object.status) : 0,
            error: isSet(object.error) ? String(object.error) : "",
            data: isSet(object.data) ? exports.Meal.fromJSON(object.data) : undefined,
        };
    },
    toJSON: function (message) {
        var obj = {};
        message.status !== undefined && (obj.status = statusToJSON(message.status));
        message.error !== undefined && (obj.error = message.error);
        message.data !== undefined && (obj.data = message.data ? exports.Meal.toJSON(message.data) : undefined);
        return obj;
    },
    create: function (base) {
        return exports.CreateMealResponse.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a, _b;
        var message = createBaseCreateMealResponse();
        message.status = (_a = object.status) !== null && _a !== void 0 ? _a : 0;
        message.error = (_b = object.error) !== null && _b !== void 0 ? _b : "";
        message.data = (object.data !== undefined && object.data !== null) ? exports.Meal.fromPartial(object.data) : undefined;
        return message;
    },
};
function createBaseFindOneRequest() {
    return { id: "" };
}
exports.FindOneRequest = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseFindOneRequest();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 10) {
                        break;
                    }
                    message.id = reader.string();
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return { id: isSet(object.id) ? String(object.id) : "" };
    },
    toJSON: function (message) {
        var obj = {};
        message.id !== undefined && (obj.id = message.id);
        return obj;
    },
    create: function (base) {
        return exports.FindOneRequest.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a;
        var message = createBaseFindOneRequest();
        message.id = (_a = object.id) !== null && _a !== void 0 ? _a : "";
        return message;
    },
};
function createBaseFindOneResponse() {
    return { status: 0, error: "", data: undefined };
}
exports.FindOneResponse = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.status !== 0) {
            writer.uint32(8).int32(message.status);
        }
        if (message.error !== "") {
            writer.uint32(18).string(message.error);
        }
        if (message.data !== undefined) {
            exports.Meal.encode(message.data, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseFindOneResponse();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 8) {
                        break;
                    }
                    message.status = reader.int32();
                    continue;
                case 2:
                    if (tag !== 18) {
                        break;
                    }
                    message.error = reader.string();
                    continue;
                case 3:
                    if (tag !== 26) {
                        break;
                    }
                    message.data = exports.Meal.decode(reader, reader.uint32());
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return {
            status: isSet(object.status) ? statusFromJSON(object.status) : 0,
            error: isSet(object.error) ? String(object.error) : "",
            data: isSet(object.data) ? exports.Meal.fromJSON(object.data) : undefined,
        };
    },
    toJSON: function (message) {
        var obj = {};
        message.status !== undefined && (obj.status = statusToJSON(message.status));
        message.error !== undefined && (obj.error = message.error);
        message.data !== undefined && (obj.data = message.data ? exports.Meal.toJSON(message.data) : undefined);
        return obj;
    },
    create: function (base) {
        return exports.FindOneResponse.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a, _b;
        var message = createBaseFindOneResponse();
        message.status = (_a = object.status) !== null && _a !== void 0 ? _a : 0;
        message.error = (_b = object.error) !== null && _b !== void 0 ? _b : "";
        message.data = (object.data !== undefined && object.data !== null) ? exports.Meal.fromPartial(object.data) : undefined;
        return message;
    },
};
var MealServiceClientImpl = (function () {
    function MealServiceClientImpl(rpc, opts) {
        this.service = (opts === null || opts === void 0 ? void 0 : opts.service) || "meal.MealService";
        this.rpc = rpc;
        this.CreateMeal = this.CreateMeal.bind(this);
        this.FindOne = this.FindOne.bind(this);
    }
    MealServiceClientImpl.prototype.CreateMeal = function (request) {
        var data = exports.CreateMealRequest.encode(request).finish();
        var promise = this.rpc.request(this.service, "CreateMeal", data);
        return promise.then(function (data) { return exports.CreateMealResponse.decode(_m0.Reader.create(data)); });
    };
    MealServiceClientImpl.prototype.FindOne = function (request) {
        var data = exports.FindOneRequest.encode(request).finish();
        var promise = this.rpc.request(this.service, "FindOne", data);
        return promise.then(function (data) { return exports.FindOneResponse.decode(_m0.Reader.create(data)); });
    };
    return MealServiceClientImpl;
}());
exports.MealServiceClientImpl = MealServiceClientImpl;
function isSet(value) {
    return value !== null && value !== undefined;
}
//# sourceMappingURL=meal.js.map