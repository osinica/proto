"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthServiceClientImpl = exports.ValidateResponse = exports.ValidateRequest = exports.protobufPackage = void 0;
var Long = require("long");
var _m0 = require("protobufjs/minimal");
exports.protobufPackage = "auth";
function createBaseValidateRequest() {
    return { token: "" };
}
exports.ValidateRequest = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.token !== "") {
            writer.uint32(10).string(message.token);
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseValidateRequest();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 10) {
                        break;
                    }
                    message.token = reader.string();
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return { token: isSet(object.token) ? String(object.token) : "" };
    },
    toJSON: function (message) {
        var obj = {};
        message.token !== undefined && (obj.token = message.token);
        return obj;
    },
    create: function (base) {
        return exports.ValidateRequest.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a;
        var message = createBaseValidateRequest();
        message.token = (_a = object.token) !== null && _a !== void 0 ? _a : "";
        return message;
    },
};
function createBaseValidateResponse() {
    return { status: 0, error: "", userId: "" };
}
exports.ValidateResponse = {
    encode: function (message, writer) {
        if (writer === void 0) { writer = _m0.Writer.create(); }
        if (message.status !== 0) {
            writer.uint32(8).int64(message.status);
        }
        if (message.error !== "") {
            writer.uint32(18).string(message.error);
        }
        if (message.userId !== "") {
            writer.uint32(26).string(message.userId);
        }
        return writer;
    },
    decode: function (input, length) {
        var reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
        var end = length === undefined ? reader.len : reader.pos + length;
        var message = createBaseValidateResponse();
        while (reader.pos < end) {
            var tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if (tag !== 8) {
                        break;
                    }
                    message.status = longToNumber(reader.int64());
                    continue;
                case 2:
                    if (tag !== 18) {
                        break;
                    }
                    message.error = reader.string();
                    continue;
                case 3:
                    if (tag !== 26) {
                        break;
                    }
                    message.userId = reader.string();
                    continue;
            }
            if ((tag & 7) === 4 || tag === 0) {
                break;
            }
            reader.skipType(tag & 7);
        }
        return message;
    },
    fromJSON: function (object) {
        return {
            status: isSet(object.status) ? Number(object.status) : 0,
            error: isSet(object.error) ? String(object.error) : "",
            userId: isSet(object.userId) ? String(object.userId) : "",
        };
    },
    toJSON: function (message) {
        var obj = {};
        message.status !== undefined && (obj.status = Math.round(message.status));
        message.error !== undefined && (obj.error = message.error);
        message.userId !== undefined && (obj.userId = message.userId);
        return obj;
    },
    create: function (base) {
        return exports.ValidateResponse.fromPartial(base !== null && base !== void 0 ? base : {});
    },
    fromPartial: function (object) {
        var _a, _b, _c;
        var message = createBaseValidateResponse();
        message.status = (_a = object.status) !== null && _a !== void 0 ? _a : 0;
        message.error = (_b = object.error) !== null && _b !== void 0 ? _b : "";
        message.userId = (_c = object.userId) !== null && _c !== void 0 ? _c : "";
        return message;
    },
};
var AuthServiceClientImpl = (function () {
    function AuthServiceClientImpl(rpc, opts) {
        this.service = (opts === null || opts === void 0 ? void 0 : opts.service) || "auth.AuthService";
        this.rpc = rpc;
        this.Validate = this.Validate.bind(this);
    }
    AuthServiceClientImpl.prototype.Validate = function (request) {
        var data = exports.ValidateRequest.encode(request).finish();
        var promise = this.rpc.request(this.service, "Validate", data);
        return promise.then(function (data) { return exports.ValidateResponse.decode(_m0.Reader.create(data)); });
    };
    return AuthServiceClientImpl;
}());
exports.AuthServiceClientImpl = AuthServiceClientImpl;
var tsProtoGlobalThis = (function () {
    if (typeof globalThis !== "undefined") {
        return globalThis;
    }
    if (typeof self !== "undefined") {
        return self;
    }
    if (typeof window !== "undefined") {
        return window;
    }
    if (typeof global !== "undefined") {
        return global;
    }
    throw "Unable to locate global object";
})();
function longToNumber(long) {
    if (long.gt(Number.MAX_SAFE_INTEGER)) {
        throw new tsProtoGlobalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
    }
    return long.toNumber();
}
if (_m0.util.Long !== Long) {
    _m0.util.Long = Long;
    _m0.configure();
}
function isSet(value) {
    return value !== null && value !== undefined;
}
//# sourceMappingURL=auth.js.map